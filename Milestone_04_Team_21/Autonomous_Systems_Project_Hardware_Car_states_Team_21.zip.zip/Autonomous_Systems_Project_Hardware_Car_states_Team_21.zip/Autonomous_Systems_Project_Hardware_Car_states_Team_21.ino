#include <ESP32Servo.h>
#include <Wire.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>

// ── Pins ──
#define ENA        14
#define IN1        26
#define IN2        27
#define SERVO_PIN  13
#define ENCODER_A  32
#define ENCODER_B  33

// ── PWM ──
#define PWM_FREQ   300
#define PWM_RES    8
#define PWM_CH     0

// ── Encoder ──
#define CPR          374
#define MAX_RPM      180.0
#define WHEEL_RADIUS 0.03

// ── Servo ──
#define SERVO_CENTER 90
#define SERVO_RANGE  75

// ── P Controller ──
float Kp = 2.0;

Servo steeringServo;
Adafruit_MPU6050 mpu;
bool imu_available = false;

// ── Commands from Pi ──
float desired_speed    = 0.0;
float desired_steering = 0.0;

// ── Encoder ──
volatile long encoder_ticks = 0;
long last_ticks             = 0;
unsigned long last_rpm_time = 0;
float rpm                   = 0.0;
int pwm_output              = 0;

// ── Odometry ──
float pos_x = 0.0;
float pos_y = 0.0;
float theta = 0.0;

// ── IMU ──
float gyro_z_offset      = 0.0;
unsigned long last_imu_time = 0;

// ── Send timer ──
unsigned long last_send_time = 0;

// ── Encoder ISR ──
void IRAM_ATTR encoderISR()
{
    if (digitalRead(ENCODER_B)) encoder_ticks++;
    else                         encoder_ticks--;
}

// ══════════════════════════════════════
void setup()
{
    Serial.begin(115200);
    delay(1000);
    Serial.println("INFO:STARTING...");

    // ── Motor ──
    pinMode(IN1, OUTPUT);
    pinMode(IN2, OUTPUT);
    digitalWrite(IN1, LOW);
    digitalWrite(IN2, LOW);
    ledcAttachChannel(ENA, PWM_FREQ, PWM_RES, PWM_CH);
    ledcWriteChannel(PWM_CH, 0);
    Serial.println("INFO:Motor OK");

    // ── Encoder ──
    pinMode(ENCODER_A, INPUT_PULLUP);
    pinMode(ENCODER_B, INPUT_PULLUP);
    attachInterrupt(digitalPinToInterrupt(ENCODER_A), encoderISR, RISING);
    Serial.println("INFO:Encoder OK");

    // ── Servo ──
    ESP32PWM::allocateTimer(0);
    ESP32PWM::allocateTimer(1);
    steeringServo.setPeriodHertz(50);
    steeringServo.attach(SERVO_PIN, 500, 2400);
    steeringServo.write(SERVO_CENTER);
    Serial.println("INFO:Servo OK");

    // ── IMU ──
    Serial.println("INFO:Initializing IMU...");
    Wire.begin(21, 22);
    Wire.setClock(400000);

    if (mpu.begin())
    {
        imu_available = true;
        mpu.setGyroRange(MPU6050_RANGE_250_DEG);
        mpu.setAccelerometerRange(MPU6050_RANGE_2_G);
        mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);
        Serial.println("INFO:MPU6050 OK");
        delay(200);
        calibrateGyro();
    }
    else
    {
        imu_available = false;
        Serial.println("INFO:MPU6050 NOT FOUND - running without IMU");
        Serial.println("INFO:Check wiring SDA=GPIO21 SCL=GPIO22");
    }

    last_rpm_time  = millis();
    last_imu_time  = millis();
    last_send_time = millis();

    Serial.println("INFO:ESP32 MS4 READY");
}

// ══════════════════════════════════════
void loop()
{
    readSerial();
    updateRPM();

    if (imu_available)
        updateIMU();

    updateOdometry();
    speedController();
    updateSteering();
    sendStatesToPi();

    delay(20);
}

// ══════════════════════════════════════
void readSerial()
{
    while (Serial.available())
    {
        String line = Serial.readStringUntil('\n');
        line.trim();

        if (line.startsWith("CMD:"))
        {
            String data = line.substring(4);
            int c = data.indexOf(',');
            if (c != -1)
            {
                desired_speed    = data.substring(0, c).toFloat();
                desired_steering = data.substring(c + 1).toFloat();
            }
        }
        else if (line == "RESET")
        {
            pos_x         = 0.0;
            pos_y         = 0.0;
            theta         = 0.0;
            encoder_ticks = 0;
            pwm_output    = 0;
            Serial.println("INFO:Reset OK");
        }
    }
}

// ══════════════════════════════════════
void updateRPM()
{
    unsigned long now = millis();
    unsigned long dt  = now - last_rpm_time;

    if (dt >= 100)
    {
        long delta    = encoder_ticks - last_ticks;
        rpm           = ((float)delta / CPR) * (60000.0 / dt);
        last_ticks    = encoder_ticks;
        last_rpm_time = now;
    }
}

// ══════════════════════════════════════
void calibrateGyro()
{
    Serial.println("INFO:Calibrating gyro - keep still...");
    float sum = 0.0;

    for (int i = 0; i < 100; i++)
    {
        sensors_event_t a, g, temp;
        mpu.getEvent(&a, &g, &temp);
        sum += g.gyro.z;
        delay(10);
    }

    gyro_z_offset = sum / 100.0;
    Serial.print("INFO:Gyro offset=");
    Serial.println(gyro_z_offset, 6);
}

// ══════════════════════════════════════
void updateIMU()
{
    unsigned long now = millis();
    float dt          = (now - last_imu_time) / 1000.0;
    last_imu_time     = now;

    sensors_event_t a, g, temp;
    mpu.getEvent(&a, &g, &temp);

    float gz = g.gyro.z - gyro_z_offset;

    if (abs(gz) > 0.07)
        theta += gz * dt;
}

// ══════════════════════════════════════
void updateOdometry()
{
    float vd = (abs(rpm) / 60.0) * 2.0 * PI * WHEEL_RADIUS;
    if (desired_speed < -0.05) vd = -vd;

    // ── Deadband: ignore tiny RPM (noise) ──
    if (abs(rpm) < 5.0) vd = 0.0;

    float dt = 0.02;
    pos_x += vd * cos(theta) * dt;
    pos_y += vd * sin(theta) * dt;
}

// ══════════════════════════════════════
void speedController()
{
    float target = abs(desired_speed) * MAX_RPM;
    float actual = abs(rpm);
    float error  = target - actual;

    pwm_output += (int)(Kp * error);
    pwm_output = constrain(pwm_output, 0, 255);

    if (desired_speed > 0.05)
    {
        digitalWrite(IN1, HIGH);
        digitalWrite(IN2, LOW);
        ledcWriteChannel(PWM_CH, pwm_output);
    }
    else if (desired_speed < -0.05)
    {
        digitalWrite(IN1, LOW);
        digitalWrite(IN2, HIGH);
        ledcWriteChannel(PWM_CH, pwm_output);
    }
    else
    {
        digitalWrite(IN1, LOW);
        digitalWrite(IN2, LOW);
        ledcWriteChannel(PWM_CH, 0);
        pwm_output = 0;
    }
}

// ══════════════════════════════════════
void updateSteering()
{
    int angle = SERVO_CENTER - (int)(desired_steering * SERVO_RANGE);
    angle = constrain(angle, 0, 180);
    steeringServo.write(angle);
}

// ══════════════════════════════════════
void sendStatesToPi()
{
    unsigned long now = millis();
    if (now - last_send_time >= 100)
    {
        float vd = (abs(rpm) / 60.0) * 2.0 * PI * WHEEL_RADIUS;
        if (desired_speed < -0.05) vd = -vd;

        Serial.print("STATE:");
        Serial.print(vd,    4);
        Serial.print(",");
        Serial.print(pos_x, 4);
        Serial.print(",");
        Serial.print(pos_y, 4);
        Serial.print(",");
        Serial.println(theta, 4);

        last_send_time = now;
    }
}