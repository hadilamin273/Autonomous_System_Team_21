from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import IncludeLaunchDescription, ExecuteProcess
from launch.launch_description_sources import PythonLaunchDescriptionSource
from ament_index_python.packages import get_package_share_directory
import os

# ─────────────────────────────────────────────
# CHANGE THIS TO 1, 2, OR 3
# MUST MATCH ackermann_drive_custom.launch.py
TRACK_NUMBER = 3
# ─────────────────────────────────────────────

def generate_launch_description():

    print(f'\n=== MS4 Launch | Track: {TRACK_NUMBER} ===\n')

    ackermann_gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            os.path.join(
                get_package_share_directory('Autonomous_Systems_Project_Team_21'),
                'launch',
                'ackermann_drive_custom.launch.py'
            )
        ])
    )

    planning_node = Node(
        package='Autonomous_Systems_Project_Team_21',
        executable='planning_node',
        name='autonomous_systems_ms4_planning_node',
        parameters=[{
            'track_number':  TRACK_NUMBER,
            'max_speed':     1.0,
            'slow_speed':    0.4,
            'lane_1':        0.1875,
            'lane_2':       -0.1875,
        }],
        output='screen'
    )

    speed_controller = Node(
        package='Autonomous_Systems_Project_Team_21',
        executable='speed_controller',
        name='autonomous_systems_ms3_speed_controller',
        parameters=[{
            'desired_speed': 1.0,
            'kp_speed':      0.5,
        }],
        output='screen'
    )

    lateral_controller = Node(
        package='Autonomous_Systems_Project_Team_21',
        executable='lateral_controller',
        name='autonomous_systems_ms3_lateral_controller',
        parameters=[{
            'desired_lane':   0.0,
            'lookahead_dist': 0.8,
            'wheelbase':      0.34,
            'kp_steering':    1.5,
        }],
        output='screen'
    )
    
    rqt_graph = ExecuteProcess(
        cmd=['ros2', 'run', 'rqt_graph', 'rqt_graph'],
        output='screen'
    )

    return LaunchDescription([
        ackermann_gazebo,
        planning_node,
        speed_controller,
        lateral_controller,
        rqt_graph,
    ])