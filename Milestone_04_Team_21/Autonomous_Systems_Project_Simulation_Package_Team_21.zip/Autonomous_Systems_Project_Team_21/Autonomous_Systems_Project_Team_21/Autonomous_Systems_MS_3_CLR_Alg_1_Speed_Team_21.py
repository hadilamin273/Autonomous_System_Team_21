#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from std_msgs.msg import Float64
import math

class SpeedController(Node):

    def __init__(self):
        super().__init__('autonomous_systems_ms3_speed_controller')

        self.declare_parameter('desired_speed', 1.0)
        self.declare_parameter('kp_speed',      0.5)

        self.desired_speed = self.get_parameter('desired_speed').value
        self.kp            = self.get_parameter('kp_speed').value
        self.actual_speed  = 0.0

        self.get_logger().info('=== Speed Controller (Feedforward + P) Started ===')

        self.speed_cmd_pub = self.create_publisher(
            Float64, '/control/speed_command', 10
        )

        self.odom_sub = self.create_subscription(
            Odometry,
            '/ackermann_steering_controller/odometry',
            self.odom_callback, 10
        )

        self.speed_sub = self.create_subscription(
            Float64, '/planning/desired_speed',
            self.speed_callback, 10
        )

        self.timer = self.create_timer(0.05, self.control_loop)

    def odom_callback(self, msg):
        vx = msg.twist.twist.linear.x
        vy = msg.twist.twist.linear.y
        self.actual_speed = math.sqrt(vx**2 + vy**2)

    def speed_callback(self, msg):
        self.desired_speed = msg.data

    def control_loop(self):
        self.kp = self.get_parameter('kp_speed').value

        error = self.desired_speed - self.actual_speed
        control_effort = self.desired_speed + self.kp * error
        control_effort = max(0.0, min(5.0, control_effort))

        msg = Float64()
        msg.data = control_effort
        self.speed_cmd_pub.publish(msg)

        self.get_logger().info(
            f'Desired: {self.desired_speed:.2f} | '
            f'Actual: {self.actual_speed:.2f} | '
            f'Command: {control_effort:.2f}'
        )

def main(args=None):
    rclpy.init(args=args)
    node = SpeedController()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()