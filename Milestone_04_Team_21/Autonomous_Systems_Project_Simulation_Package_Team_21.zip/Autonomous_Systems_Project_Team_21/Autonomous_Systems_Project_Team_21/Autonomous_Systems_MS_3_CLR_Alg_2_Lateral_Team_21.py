#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import TwistStamped
from nav_msgs.msg import Odometry
from sensor_msgs.msg import JointState
from std_msgs.msg import Float64, Float64MultiArray
import math

class LateralController(Node):

    def __init__(self):
        super().__init__('autonomous_systems_ms3_lateral_controller')

        self.declare_parameter('desired_lane',    0.0)
        self.declare_parameter('lookahead_dist',  0.8)
        self.declare_parameter('wheelbase',       0.34)
        self.declare_parameter('kp_steering',     1.5)

        self.desired_lane    = self.get_parameter('desired_lane').value
        self.lookahead_dist  = self.get_parameter('lookahead_dist').value
        self.wheelbase       = self.get_parameter('wheelbase').value
        self.kp_steering     = self.get_parameter('kp_steering').value

        # Vehicle state from odometry
        self.x               = 0.0
        self.y               = 0.0
        self.yaw             = 0.0

        # Actual steering from joint states
        self.actual_steering = 0.0

        # Speed from speed controller
        self.speed_command   = 0.0

        # Steering rate limiter
        self.last_steering   = 0.0

        # Waypoint mode for Track 3
        self.waypoint_x = None
        self.waypoint_y = None

        self.get_logger().info('=== Lateral Controller (Pure Pursuit + Joint States) ===')

        # Publisher
        self.cmd_pub = self.create_publisher(
            TwistStamped,
            '/ackermann_steering_controller/reference',
            10
        )

        # Subscriber — odometry for position and yaw
        self.odom_sub = self.create_subscription(
            Odometry,
            '/ackermann_steering_controller/odometry',
            self.odom_callback, 10
        )

        # Subscriber — joint states for actual steering angle
        self.joint_sub = self.create_subscription(
            JointState,
            '/joint_states',
            self.joint_callback, 10
        )

        # Subscriber — desired lane (Track 1 and 2)
        self.lane_sub = self.create_subscription(
            Float64,
            '/planning/desired_lane',
            self.lane_callback, 10
        )

        # Subscriber — desired waypoint (Track 3)
        self.waypoint_sub = self.create_subscription(
            Float64MultiArray,
            '/planning/desired_waypoint',
            self.waypoint_callback, 10
        )

        # Subscriber — speed command from speed controller
        self.speed_cmd_sub = self.create_subscription(
            Float64,
            '/control/speed_command',
            self.speed_cmd_callback, 10
        )

        self.timer = self.create_timer(0.05, self.control_loop)

    def odom_callback(self, msg):
        self.x = msg.pose.pose.position.x
        self.y = msg.pose.pose.position.y

        qx = msg.pose.pose.orientation.x
        qy = msg.pose.pose.orientation.y
        qz = msg.pose.pose.orientation.z
        qw = msg.pose.pose.orientation.w
        self.yaw = math.atan2(
            2.0 * (qw * qz + qx * qy),
            1.0 - 2.0 * (qy * qy + qz * qz)
        )

    def joint_callback(self, msg):
        try:
            left_idx  = msg.name.index('left_wheel_steering_joint')
            right_idx = msg.name.index('right_wheel_steering_joint')
            self.actual_steering = (
                msg.position[left_idx] + msg.position[right_idx]
            ) / 2.0
        except ValueError:
            self.actual_steering = 0.0

    def lane_callback(self, msg):
        self.desired_lane = msg.data
        self.waypoint_x   = None
        self.waypoint_y   = None

    def waypoint_callback(self, msg):
        if len(msg.data) >= 2:
            self.waypoint_x = msg.data[0]
            self.waypoint_y = msg.data[1]

    def speed_cmd_callback(self, msg):
        self.speed_command = msg.data

    def control_loop(self):
        self.lookahead_dist = self.get_parameter('lookahead_dist').value
        self.wheelbase      = self.get_parameter('wheelbase').value
        self.kp_steering    = self.get_parameter('kp_steering').value

        # ── Step 1: Pure Pursuit computes desired steering ──
        if self.waypoint_x is not None and self.waypoint_y is not None:
            goal_x = self.waypoint_x
            goal_y = self.waypoint_y
            mode   = 'WP'
        else:
            goal_x = self.x + self.lookahead_dist * math.cos(self.yaw)
            goal_y = self.desired_lane
            mode   = 'LANE'

        desired_steering = self.pure_pursuit(goal_x, goal_y)

        # ── Step 2: P controller on actual vs desired steering ──
        # Uses joint_states feedback for closed loop steering
        steering_error   = desired_steering - self.actual_steering
        steering_output  = desired_steering + self.kp_steering * steering_error

        # Clamp
        steering_output = max(-0.9, min(0.9, steering_output))

        # ── Step 3: Rate limiter for smooth steering ──
        max_change = 0.5
        diff = steering_output - self.last_steering
        if diff > max_change:
            steering_output = self.last_steering + max_change
        elif diff < -max_change:
            steering_output = self.last_steering - max_change
        self.last_steering = steering_output

        # ── Publish combined command ──
        msg = TwistStamped()
        msg.header.stamp    = self.get_clock().now().to_msg()
        msg.header.frame_id = 'base_link'
        msg.twist.linear.x  = self.speed_command
        msg.twist.angular.z = steering_output
        self.cmd_pub.publish(msg)

        if mode == 'LANE':
            self.get_logger().info(
                f'LANE | Pos: ({self.x:.2f}, {self.y:.2f}) | '
                f'Desired: {self.desired_lane:.3f} | '
                f'Error: {self.desired_lane - self.y:.3f} | '
                f'DesiredSteer: {desired_steering:.3f} | '
                f'ActualSteer: {self.actual_steering:.3f} | '
                f'Output: {steering_output:.3f}'
            )
        else:
            dist = math.sqrt(
                (goal_x - self.x)**2 + (goal_y - self.y)**2
            )
            self.get_logger().info(
                f'WP | Pos: ({self.x:.2f}, {self.y:.2f}) | '
                f'Goal: ({goal_x:.2f}, {goal_y:.2f}) | '
                f'Dist: {dist:.2f} | '
                f'DesiredSteer: {desired_steering:.3f} | '
                f'ActualSteer: {self.actual_steering:.3f} | '
                f'Output: {steering_output:.3f}'
            )

    def pure_pursuit(self, goal_x, goal_y):
        dx = goal_x - self.x
        dy = goal_y - self.y

        # Transform to vehicle frame
        local_x =  dx * math.cos(self.yaw) + dy * math.sin(self.yaw)
        local_y = -dx * math.sin(self.yaw) + dy * math.cos(self.yaw)

        ld = math.sqrt(local_x**2 + local_y**2)

        if ld < 0.01:
            return 0.0

        # Pure Pursuit formula
        steering = math.atan2(2.0 * self.wheelbase * local_y, ld * ld)

        # Clamp
        steering = max(-0.9, min(0.9, steering))

        return steering

def main(args=None):
    rclpy.init(args=args)
    node = LateralController()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()