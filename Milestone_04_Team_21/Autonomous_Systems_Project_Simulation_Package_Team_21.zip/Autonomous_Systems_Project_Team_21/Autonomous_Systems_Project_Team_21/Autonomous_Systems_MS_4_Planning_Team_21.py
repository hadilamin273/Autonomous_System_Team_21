#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64, Float64MultiArray
from nav_msgs.msg import Odometry
import math

class PlanningNode(Node):

    def __init__(self):
        super().__init__('autonomous_systems_ms4_planning_node')

        self.declare_parameter('track_number',   1)
        self.declare_parameter('max_speed',      1.0)
        self.declare_parameter('slow_speed',     0.4)
        self.declare_parameter('lane_1',         0.15)
        self.declare_parameter('lane_2',        -0.15)

        self.track_number = self.get_parameter('track_number').value
        self.max_speed    = self.get_parameter('max_speed').value
        self.slow_speed   = self.get_parameter('slow_speed').value
        self.lane_1       = self.get_parameter('lane_1').value
        self.lane_2       = self.get_parameter('lane_2').value

        self.x = 0.0
        self.y = 0.0

        self.desired_speed = 0.0
        self.desired_lane  = 0.0
# Track 3 waypoints — 0.75m track width
        # Outer: x=-2.5 to 2.5, y=-0.25 to 3.75
        # Inner: x=-1.75 to 1.75, y=0.5 to 3.0
        # Center lines:
        #   Bottom: y=0.125   Right: x=2.125
        #   Top: y=3.375      Left: x=-2.125
        # Corners sweep toward OUTER wall to avoid inner wall
        self.waypoints = [
            # ── Bottom straight ──
            ( 0.5,   0.15, self.max_speed),
            ( 1.0,   0.15, self.max_speed),

            # ── Corner 1: Bottom-right ──
            ( 1.5,   0.15, self.slow_speed),
            ( 1.9,   0.5,  self.slow_speed),
            ( 1.9,   1.0,  self.slow_speed),

            # ── Right straight ──
            ( 2.1,   1.5,  self.max_speed),
            ( 2.1,   2.0,  self.max_speed),
            ( 2.1,   2.5,  self.max_speed),

            # ── Corner 2: Top-right ──
            ( 2.1,   3.0,  self.slow_speed),
            ( 1.7,   3.1,  self.slow_speed),
            ( 1.6,   3.3,  self.slow_speed),

            # ── Top straight ──
            ( 1.0,   3.4,  self.max_speed),
            (-0.5,   3.4,  self.max_speed),

            # ── Corner 3: Top-left ──
            (-1.9,   3.3,  self.slow_speed),
            (-2.1,   2.8,  self.slow_speed),

            # ── Left straight ──
            (-2.1,   2.0,  self.max_speed),
            (-2.1,   1.5,  self.max_speed),

            # ── Corner 4: Bottom-left (mirror of corner 1) ──
            (-2,   1.0,  self.slow_speed),
            (-2,   0.45,  self.slow_speed),
            (-1.9,   0.45,  self.slow_speed),
            (-1.5,   0.15, self.slow_speed),

            # ── Back to start ──
            (-0.5,   0.15, self.max_speed),
            ( 0.0,   0.15, self.slow_speed),
        ]
        self.wp_index = 0

        self.get_logger().info(f'=== Planning Node | Track: {self.track_number} ===')

        # Publishers
        self.speed_pub = self.create_publisher(
            Float64, '/planning/desired_speed', 10
        )
        self.lane_pub = self.create_publisher(
            Float64, '/planning/desired_lane', 10
        )
        self.waypoint_pub = self.create_publisher(
            Float64MultiArray, '/planning/desired_waypoint', 10
        )

        # Subscriber
        self.odom_sub = self.create_subscription(
            Odometry,
            '/ackermann_steering_controller/odometry',
            self.odom_callback, 10
        )

        self.timer = self.create_timer(0.1, self.planning_loop)

    def odom_callback(self, msg):
        self.x = msg.pose.pose.position.x
        self.y = msg.pose.pose.position.y

    def planning_loop(self):
        track = self.get_parameter('track_number').value

        if track == 1:
            self.plan_track_1()
        elif track == 2:
            self.plan_track_2()
        elif track == 3:
            self.plan_track_3()

    # ═══════════════════════════════════════
    # TRACK 1 — Straight line 10 meters
    # ═══════════════════════════════════════
    def plan_track_1(self):
        if 0.0 <= self.x < 9.0:
            self.desired_speed = self.max_speed
            self.desired_lane  = 0.0
        elif self.x >= 9.0:
            self.desired_speed = 0.0
            self.desired_lane  = 0.0
        else:
            # x is negative — keep going forward
            self.desired_speed = self.max_speed
            self.desired_lane  = 0.0

        self.publish_lane()
        self.get_logger().info(
            f'T1 | X: {self.x:.2f} | Speed: {self.desired_speed:.2f} | Lane: {self.desired_lane:.3f}'
        )

    # ═══════════════════════════════════════
    # TRACK 2 — Lane changes around obstacles
    # Obstacle 1 at x=4m blocking Lane 1
    # Obstacle 2 at x=8m blocking Lane 2
    # ═══════════════════════════════════════
    def plan_track_2(self):
        if 0.0 <= self.x < 3:
            # Start — drive in Lane 1 at full speed
            self.desired_speed = self.max_speed
            self.desired_lane  = self.lane_1

        elif 3 <= self.x < 4.1:
            # Approaching obstacle 1 — slow down, change to Lane 2
            self.desired_speed = self.slow_speed
            self.desired_lane  = self.lane_2

        elif 4.1 <= self.x < 7:
            # Past obstacle 1 — drive in Lane 2 at full speed
            self.desired_speed = self.max_speed
            self.desired_lane  = self.lane_2

        elif 7 <= self.x < 8.1:
            # Approaching obstacle 2 — slow down, change to Lane 1
            self.desired_speed = self.slow_speed
            self.desired_lane  = self.lane_1

        elif 8.1 <= self.x < 9.9:
            # Past obstacle 2 — drive in Lane 1 at full speed to end
            self.desired_speed = self.max_speed
            self.desired_lane  = self.lane_1

        elif self.x >= 9.9:
            # End of track — stop
            self.desired_speed = 0.0
            self.desired_lane  = self.lane_1

        else:
            # x is negative — safety, keep Lane 1
            self.desired_speed = self.max_speed
            self.desired_lane  = self.lane_1

        self.publish_lane()
        self.get_logger().info(
            f'T2 | X: {self.x:.2f} | Y: {self.y:.2f} | '
            f'Speed: {self.desired_speed:.2f} | Lane: {self.desired_lane:.3f}'
        )

    # ═══════════════════════════════════════
    # TRACK 3 — City track waypoint following
    # ═══════════════════════════════════════
    def plan_track_3(self):
        if self.wp_index >= len(self.waypoints):
            # Lap complete — stop
            self.desired_speed = 0.0
            speed_msg = Float64()
            speed_msg.data = 0.0
            self.speed_pub.publish(speed_msg)
            self.get_logger().info('T3 | LAP COMPLETE!')
            return

        wp_x, wp_y, wp_speed = self.waypoints[self.wp_index]
        self.desired_speed = wp_speed

        # Distance to current waypoint
        dist = math.sqrt((wp_x - self.x)**2 + (wp_y - self.y)**2)

        # If close enough, advance to next waypoint
        if dist < 0.3:
            self.wp_index += 1
            if self.wp_index < len(self.waypoints):
                nwp = self.waypoints[self.wp_index]
                self.get_logger().info(
                    f'T3 | Reached WP {self.wp_index} → Next: ({nwp[0]:.2f}, {nwp[1]:.2f})'
                )

        # Publish speed
        speed_msg = Float64()
        speed_msg.data = self.desired_speed
        self.speed_pub.publish(speed_msg)

        # Publish current waypoint target
        wp_msg = Float64MultiArray()
        if self.wp_index < len(self.waypoints):
            wp = self.waypoints[self.wp_index]
            wp_msg.data = [wp[0], wp[1]]
        else:
            wp_msg.data = [self.x, self.y]
        self.waypoint_pub.publish(wp_msg)

        self.get_logger().info(
            f'T3 | Pos: ({self.x:.2f}, {self.y:.2f}) | '
            f'WP{self.wp_index}: ({wp_x:.2f}, {wp_y:.2f}) | '
            f'Dist: {dist:.2f} | Speed: {self.desired_speed:.2f}'
        )

    def publish_lane(self):
        speed_msg = Float64()
        speed_msg.data = self.desired_speed
        self.speed_pub.publish(speed_msg)

        lane_msg = Float64()
        lane_msg.data = self.desired_lane
        self.lane_pub.publish(lane_msg)

def main(args=None):
    rclpy.init(args=args)
    node = PlanningNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()