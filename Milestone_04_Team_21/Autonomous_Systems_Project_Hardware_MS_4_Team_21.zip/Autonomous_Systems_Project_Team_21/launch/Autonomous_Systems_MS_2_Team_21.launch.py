from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import ExecuteProcess

def generate_launch_description():
    return LaunchDescription([
        # 1. Teleop Node with Params [cite: 219, 252]
        Node(
            package='Autonomous_Systems_Project_Team_21',
            executable='Autonomous_Systems_MS_2_Teleop_Team_21',
            name='teleop_node',
            output='screen', # Mandatory for evaluation [cite: 244]
            parameters=[{
                'initial_speed': 0.0,
                'desired_speed': 1.5,
                'initial_lane': 1,
                'desired_lane': 2
            }]
        ),

        # 2. Launch rqt_graph as required [cite: 254]
        ExecuteProcess(
            cmd=['rqt_graph'],
            output='screen'
        )
    ])
