from launch import LaunchDescription
from launch_ros.actions import Node

# ─────────────────────────────────────────────
# CHANGE THIS TO 1, 2, OR 3
TRACK_NUMBER = 1
# ─────────────────────────────────────────────

def generate_launch_description():

    print(f'\n=== Hardware Launch | Track: {TRACK_NUMBER} ===\n')

    localization_node = Node(
        package='Autonomous_Systems_Project_Team_21',
        executable='localization_node',
        name='autonomous_systems_ms4_localization_node',
        parameters=[{
            'serial_port': '/dev/ttyUSB0',
            'baud_rate':    115200,
        }],
        output='screen'
    )

    planning_node = Node(
        package='Autonomous_Systems_Project_Team_21',
        executable='hw_planning_node',
        name='autonomous_systems_ms4_hw_planning_node',
        parameters=[{
            'track_number': TRACK_NUMBER,
            'max_speed':    0.5,
            'slow_speed':   0.3,
            'lane_1':       0.1875,
            'lane_2':      -0.1875,
        }],
        output='screen'
    )

    hw_controller = Node(
        package='Autonomous_Systems_Project_Team_21',
        executable='hw_controller_node',
        name='autonomous_systems_ms4_hw_controller',
        parameters=[{
            'kp_speed':   0.5,
            'kp_lateral': 6.0,
        }],
        output='screen'
    )

    return LaunchDescription([
        localization_node,
        planning_node,
        hw_controller,
    ])