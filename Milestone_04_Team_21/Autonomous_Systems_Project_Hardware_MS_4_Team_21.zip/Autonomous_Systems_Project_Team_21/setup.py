from setuptools import find_packages, setup
import os
from glob import glob

package_name = 'Autonomous_Systems_Project_Team_21'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.py')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='hanafy',
    maintainer_email='hanafy@todo.todo',
    description='Autonomous Systems Project Team 21',
    license='MIT',
    extras_require={
        'test': ['pytest'],
    },
    entry_points={
        'console_scripts': [
            'validation_node   = Autonomous_Systems_Project_Team_21.Validation_Printing_Node_Team_21:main',
            'teleop_node       = Autonomous_Systems_Project_Team_21.Autonomous_Systems_MS_2_Teleop_Team_21:main',
            'localization_node = Autonomous_Systems_Project_Team_21.Autonomous_Systems_MS_4_Localization_Team_21:main',
            'hw_controller_node = Autonomous_Systems_Project_Team_21.Autonomous_Systems_MS_4_HW_Controller_Team_21:main',
            'hw_planning_node  = Autonomous_Systems_Project_Team_21.Autonomous_Systems_MS_4_HW_Planning_Team_21:main',
        ],
    },
)