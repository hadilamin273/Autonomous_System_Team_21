#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray, Float64
import math

class HardwareController(Node):

    def __init__(self):
        super().__init__('autonomous_systems_ms4_hw_controller')

        self.declare_parameter('kp_speed',   0.5)
        self.declare_parameter('kp_lateral', 2.0)

        self.kp_speed   = self.get_parameter('kp_speed').value
        self.kp_lateral = self.get_parameter('kp_lateral').value

        # States from localization
        self.vd_actual = 0.0
        self.x         = 0.0
        self.y         = 0.0
        self.theta     = 0.0

        # Desired from planning
        self.desired_speed = 0.0
        self.desired_lane  = 0.0

        # Publisher
        self.cmd_pub = self.create_publisher(
            Float64MultiArray, '/hardware/command', 10
        )

        # Subscribers
        self.states_sub = self.create_subscription(
            Float64MultiArray, '/localization/states',
            self.states_callback, 10
        )
        self.speed_sub = self.create_subscription(
            Float64, '/planning/desired_speed',
            self.speed_callback, 10
        )
        self.lane_sub = self.create_subscription(
            Float64, '/planning/desired_lane',
            self.lane_callback, 10
        )

        self.timer = self.create_timer(0.1, self.control_loop)
        self.get_logger().info('=== Hardware Controller Started ===')

    def states_callback(self, msg):
        if len(msg.data) >= 4:
            self.vd_actual = msg.data[0]
            self.x         = msg.data[1]
            self.y         = msg.data[2]
            self.theta     = msg.data[3]

    def speed_callback(self, msg):
        self.desired_speed = msg.data

    def lane_callback(self, msg):
        self.desired_lane = msg.data

    def control_loop(self):
        self.kp_speed   = self.get_parameter('kp_speed').value
        self.kp_lateral = self.get_parameter('kp_lateral').value

        # ── Speed control (feedforward + P) ──
        speed_error   = self.desired_speed - self.vd_actual
        speed_command = self.desired_speed + self.kp_speed * speed_error
        speed_command = max(0.0, min(1.0, speed_command))

        # ── Lateral control (P on y error) — NO LIMITS ──
        lateral_error    = self.desired_lane - self.y
        steering_command = self.kp_lateral * lateral_error

        # Publish command
        cmd = Float64MultiArray()
        cmd.data = [speed_command, steering_command]
        self.cmd_pub.publish(cmd)

        self.get_logger().info(
            f'X:{self.x:.2f} Y:{self.y:.2f} | '
            f'DesSpd:{self.desired_speed:.2f} ActSpd:{self.vd_actual:.2f} | '
            f'DesLane:{self.desired_lane:.3f} LatErr:{lateral_error:.3f} | '
            f'Steer:{steering_command:.3f}'
        )

def main(args=None):
    rclpy.init(args=args)
    node = HardwareController()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()