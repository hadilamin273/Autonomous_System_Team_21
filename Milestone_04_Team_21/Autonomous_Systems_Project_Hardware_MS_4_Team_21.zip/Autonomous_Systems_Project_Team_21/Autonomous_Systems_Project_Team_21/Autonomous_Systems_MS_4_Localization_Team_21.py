#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray
import serial
import threading
import math
import time

class LocalizationNode(Node):

    def __init__(self):
        super().__init__('autonomous_systems_ms4_localization_node')

        self.declare_parameter('serial_port', '/dev/ttyUSB0')
        self.declare_parameter('baud_rate',    115200)

        self.serial_port = self.get_parameter('serial_port').value
        self.baud_rate   = self.get_parameter('baud_rate').value

        # States
        self.vd    = 0.0
        self.x     = 0.0
        self.y     = 0.0
        self.theta = 0.0

        # Command to send
        self.cmd_speed    = 0.0
        self.cmd_steering = 0.0

        self.lock  = threading.Lock()
        self.esp32 = None

        # Publishers
        self.states_pub = self.create_publisher(
            Float64MultiArray, '/localization/states', 10
        )

        # Subscribers
        self.cmd_sub = self.create_subscription(
            Float64MultiArray, '/hardware/command',
            self.command_callback, 10
        )

        # Connect
        self.connect()

        # Background thread
        self.read_thread = threading.Thread(target=self.read_loop)
        self.read_thread.daemon = True
        self.read_thread.start()

        # Send at 10Hz
        self.send_timer  = self.create_timer(0.1, self.send_command)
        # Print at 1Hz
        self.print_timer = self.create_timer(1.0, self.print_states)
        # Reconnect check at 2Hz
        self.recon_timer = self.create_timer(0.5, self.check_connection)

        self.get_logger().info('=== Localization Node Started ===')

    def connect(self):
     try:
        if self.esp32:
            self.esp32.close()
        self.esp32 = serial.Serial(
            self.serial_port, self.baud_rate,
            timeout=1
        )
        time.sleep(2.0)  # wait for ESP32 to be ready

        # Reset ESP32 odometry
        self.esp32.write(b'RESET\n')
        time.sleep(0.2)

        # Reset local values too
        self.vd    = 0.0
        self.x     = 0.0
        self.y     = 0.0
        self.theta = 0.0

        self.get_logger().info(f'Connected and RESET sent to ESP32')

     except Exception as e:
        self.esp32 = None
        self.get_logger().warn(f'Cannot connect: {e}')
    def check_connection(self):
        if self.esp32 is None or not self.esp32.is_open:
            self.get_logger().warn('ESP32 disconnected — reconnecting...')
            self.connect()

    def command_callback(self, msg):
        if len(msg.data) >= 2:
            self.cmd_speed    = msg.data[0]
            self.cmd_steering = msg.data[1]

    def read_loop(self):
        line = ''
        while rclpy.ok():
            try:
                if self.esp32 and self.esp32.is_open:
                    with self.lock:
                        if self.esp32.in_waiting > 0:
                            line = self.esp32.readline().decode('utf-8').strip()
                    if line.startswith('STATE:'):
                        self.parse_state(line[6:])
                else:
                    time.sleep(0.1)
            except Exception:
                time.sleep(0.1)

    def parse_state(self, data):
        try:
            parts = data.split(',')
            if len(parts) == 4:
                self.vd    = float(parts[0])
                self.x     = float(parts[1])
                self.y     = float(parts[2])
                self.theta = float(parts[3])

                msg = Float64MultiArray()
                msg.data = [self.vd, self.x, self.y, self.theta]
                self.states_pub.publish(msg)
        except Exception:
            pass

    def send_command(self):
        if self.esp32 and self.esp32.is_open:
            try:
                cmd = f'CMD:{self.cmd_speed:.3f},{self.cmd_steering:.3f}\n'
                with self.lock:
                    self.esp32.write(cmd.encode())
            except Exception as e:
                self.get_logger().warn(f'Send error: {e}')
                self.esp32 = None

    def print_states(self):
        self.get_logger().info(
            f'Speed: {self.vd:.3f} m/s | '
            f'X: {self.x:.3f} m | '
            f'Y: {self.y:.3f} m | '
            f'Theta: {math.degrees(self.theta):.2f} deg | '
            f'CMD: ({self.cmd_speed:.2f}, {self.cmd_steering:.2f})'
        )

def main(args=None):
    rclpy.init(args=args)
    node = LocalizationNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()