


import rclpy
from rclpy.node import Node

def main(args=None):
    rclpy.init(args=args)
    node = Node('Validation_Printing_Node_Team_21')
    node.get_logger().info('Hello World')
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
