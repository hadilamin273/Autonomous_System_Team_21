#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import TwistStamped
from nav_msgs.msg import Odometry
import sys
import tty
import termios
import threading
import math
import time

try:
    import serial
    SERIAL_AVAILABLE = True
except ImportError:
    SERIAL_AVAILABLE = False

ARROW_UP    = '\x1b[A'
ARROW_DOWN  = '\x1b[B'
ARROW_RIGHT = '\x1b[C'
ARROW_LEFT  = '\x1b[D'

class TeleopNode(Node):

    def __init__(self):
        super().__init__('autonomous_systems_ms2_teleop_node')

        # ROS Parameters
        self.declare_parameter('initial_speed', 0.0)
        self.declare_parameter('desired_speed', 2.0)
        self.declare_parameter('initial_lane',  0.0)
        self.declare_parameter('desired_lane',  1.0)
        self.declare_parameter('serial_port',  '/dev/ttyUSB0')
        self.declare_parameter('baud_rate',     115200)

        self.speed    = self.get_parameter('desired_speed').value
        self.steering = self.get_parameter('desired_lane').value
        serial_port   = self.get_parameter('serial_port').value
        baud_rate     = self.get_parameter('baud_rate').value

        self.current_speed    = 0.0
        self.current_steering = 0.0

        # Connect to ESP32
        self.esp32 = None
        if SERIAL_AVAILABLE:
            try:
                self.esp32 = serial.Serial(serial_port, baud_rate, timeout=1)
                time.sleep(2)
                self.get_logger().info(f'Connected to ESP32 on {serial_port}')
            except Exception as e:
                self.get_logger().warn(f'Could not connect to ESP32: {e}')
                self.get_logger().warn('Running in simulation-only mode')
        else:
            self.get_logger().warn('pyserial not installed — simulation only')

        self.get_logger().info('=== Teleop Node Started ===')
        self.get_logger().info('UP=forward | DOWN=backward | LEFT=steer left | RIGHT=steer right | SPACE=stop | CTRL+C=exit')

        # Publisher
        self.cmd_pub = self.create_publisher(
            TwistStamped,
            '/ackermann_steering_controller/reference',
            10
        )

        # Subscriber
        self.odom_sub = self.create_subscription(
            Odometry,
            '/ackermann_steering_controller/odometry',
            self.odom_callback,
            10
        )

        # Keyboard thread
        self.thread = threading.Thread(target=self.keyboard_loop)
        self.thread.daemon = True
        self.thread.start()

    def get_key(self):
        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch1 = sys.stdin.read(1)
            if ch1 == '\x1b':
                ch2 = sys.stdin.read(1)
                ch3 = sys.stdin.read(1)
                return ch1 + ch2 + ch3
            return ch1
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)

    def send_to_esp32(self, speed, steering):
        if self.esp32 and self.esp32.is_open:
            try:
                command = f'{speed:.2f},{steering:.2f}\n'
                self.esp32.write(command.encode())
            except Exception as e:
                self.get_logger().warn(f'Serial error: {e}')

    def publish_cmd(self):
        msg = TwistStamped()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = 'base_link'
        msg.twist.linear.x  = self.current_speed
        msg.twist.angular.z = self.current_steering
        self.cmd_pub.publish(msg)
        self.send_to_esp32(self.current_speed, self.current_steering)

    def keyboard_loop(self):
        while rclpy.ok():
            key = self.get_key()

            if key == ARROW_UP:
                self.current_speed = self.speed
                self.get_logger().info(f'Forward | Speed: {self.current_speed} m/s')
            elif key == ARROW_DOWN:
                self.current_speed = -self.speed
                self.get_logger().info(f'Backward | Speed: {self.current_speed} m/s')
            elif key == ARROW_LEFT:
                self.current_steering = self.steering
                self.get_logger().info(f'Steering Left | Angle: {self.current_steering} rad')
            elif key == ARROW_RIGHT:
                self.current_steering = -self.steering
                self.get_logger().info(f'Steering Right | Angle: {self.current_steering} rad')
            elif key == ' ':
                self.current_speed    = 0.0
                self.current_steering = 0.0
                self.get_logger().info('Stopped')
            elif key == '\x03':
                break

            self.publish_cmd()

    def odom_callback(self, msg):
        x  = msg.pose.pose.position.x
        y  = msg.pose.pose.position.y
        vx = msg.twist.twist.linear.x
        vy = msg.twist.twist.linear.y
        speed = math.sqrt(vx**2 + vy**2)
        qz  = msg.pose.pose.orientation.z
        qw  = msg.pose.pose.orientation.w
        yaw = 2.0 * math.atan2(qz, qw)

        self.get_logger().info(
            f'Position: ({x:.2f}, {y:.2f}) | '
            f'Speed: {speed:.2f} m/s | '
            f'Yaw: {math.degrees(yaw):.2f} deg'
        )

    def destroy_node(self):
        if self.esp32 and self.esp32.is_open:
            self.send_to_esp32(0.0, 0.0)
            self.esp32.close()
        super().destroy_node()

def main(args=None):
    rclpy.init(args=args)
    node = TeleopNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
