#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64, Float64MultiArray
import math

class HardwarePlanningNode(Node):

    def __init__(self):
        super().__init__('autonomous_systems_ms4_hw_planning_node')

        # ─────────────────────────────────────
        # CHANGE THIS TO 1, 2, OR 3
        self.declare_parameter('track_number',  1)
        self.declare_parameter('max_speed',     0.5)
        self.declare_parameter('slow_speed',    0.3)
        # Exact same as simulation
        self.declare_parameter('lane_1',        0.1875)
        self.declare_parameter('lane_2',       -0.1875)
        # ─────────────────────────────────────

        self.track_number = self.get_parameter('track_number').value
        self.max_speed    = self.get_parameter('max_speed').value
        self.slow_speed   = self.get_parameter('slow_speed').value
        self.lane_1       = self.get_parameter('lane_1').value
        self.lane_2       = self.get_parameter('lane_2').value

        self.x        = 0.0
        self.y        = 0.0
        self.reset_done = False

        # Track 3 waypoints — same scale as simulation
        self.waypoints = [
            # Bottom straight
            ( 0.5,   0.0,   self.max_speed),
            ( 1.0,   0.0,   self.max_speed),
            # Bottom-right corner
            ( 1.5,   0.0,   self.slow_speed),
            ( 1.9,   0.5,   self.slow_speed),
            ( 1.9,   1.0,   self.slow_speed),
            # Right straight
            ( 1.9,   1.5,   self.max_speed),
            ( 1.9,   2.0,   self.max_speed),
            ( 1.9,   2.5,   self.max_speed),
            # Top-right corner
            ( 1.9,   3.0,   self.slow_speed),
            ( 1.6,   3.3,   self.slow_speed),
            # Top straight
            ( 0.5,   3.3,   self.max_speed),
            (-0.5,   3.3,   self.max_speed),
            # Top-left corner
            (-1.6,   3.3,   self.slow_speed),
            (-1.9,   3.0,   self.slow_speed),
            # Left straight
            (-1.9,   2.0,   self.max_speed),
            (-1.9,   1.5,   self.max_speed),
            # Bottom-left corner
            (-1.9,   1.0,   self.slow_speed),
            (-1.9,   0.5,   self.slow_speed),
            (-1.5,   0.0,   self.slow_speed),
            # Back to start
            (-0.5,   0.0,   self.max_speed),
            ( 0.0,   0.0,   self.slow_speed),
        ]
        self.wp_index = 0

        self.get_logger().info(
            f'=== HW Planning Node | Track: {self.track_number} ==='
        )

        # Publishers
        self.speed_pub = self.create_publisher(Float64, '/planning/desired_speed', 10)
        self.lane_pub  = self.create_publisher(Float64, '/planning/desired_lane',  10)
        self.reset_pub = self.create_publisher(Float64MultiArray, '/hardware/reset', 10)

        # Subscriber
        self.states_sub = self.create_subscription(
            Float64MultiArray, '/localization/states',
            self.states_callback, 10
        )

        # Reset after 3 seconds
        self.reset_timer = self.create_timer(3.0, self.send_reset)
        self.plan_timer  = self.create_timer(0.1, self.planning_loop)

    def states_callback(self, msg):
        if len(msg.data) >= 4:
            self.x = msg.data[1]
            self.y = msg.data[2]

    def send_reset(self):
        if not self.reset_done:
            self.get_logger().info('=== Sending RESET ===')
            msg = Float64MultiArray()
            msg.data = [0.0]
            self.reset_pub.publish(msg)
            self.reset_done = True
            self.wp_index   = 0
            self.reset_timer.cancel()

    def planning_loop(self):
        if not self.reset_done:
            self.publish(0.0, 0.0)
            return

        track = self.get_parameter('track_number').value

        if track == 1:
            self.plan_track_1()
        elif track == 2:
            self.plan_track_2()
        elif track == 3:
            self.plan_track_3()

    # ═══════════════════════════════════════
    # TRACK 1 — Straight 10 meters
    # Same as simulation
    # ═══════════════════════════════════════
    def plan_track_1(self):
        if 0.0 <= self.x < 9.5:
            speed = self.max_speed
            lane  = 0.0
        elif self.x >= 9.5:
            speed = 0.0
            lane  = 0.0
        else:
            speed = self.max_speed
            lane  = 0.0

        self.publish(speed, lane)
        self.get_logger().info(
            f'T1 | X:{self.x:.2f} | Spd:{speed:.2f} | Lane:{lane:.3f}'
        )

    # ═══════════════════════════════════════
    # TRACK 2 — Double lane change
    # Same as simulation:
    # Obstacle 1 at 4m → change to Lane 2
    # Obstacle 2 at 8m → change back to Lane 1
    # ═══════════════════════════════════════
    def plan_track_2(self):
        if 0.0 <= self.x < 3.0:
            speed = self.max_speed
            lane  = self.lane_1

        elif 3.0 <= self.x < 4.5:
            speed = self.slow_speed
            lane  = self.lane_2

        elif 4.5 <= self.x < 7.0:
            speed = self.max_speed
            lane  = self.lane_2

        elif 7.0 <= self.x < 8.5:
            speed = self.slow_speed
            lane  = self.lane_1

        elif 8.5 <= self.x < 9.5:
            speed = self.max_speed
            lane  = self.lane_1

        elif self.x >= 9.5:
            speed = 0.0
            lane  = self.lane_1

        else:
            speed = self.max_speed
            lane  = self.lane_1

        self.publish(speed, lane)
        self.get_logger().info(
            f'T2 | X:{self.x:.2f} Y:{self.y:.2f} | '
            f'Spd:{speed:.2f} | Lane:{lane:.3f}'
        )

    # ═══════════════════════════════════════
    # TRACK 3 — City track
    # ═══════════════════════════════════════
    def plan_track_3(self):
        if self.wp_index >= len(self.waypoints):
            self.publish(0.0, 0.0)
            self.get_logger().info('T3 | LAP COMPLETE!')
            return

        wp_x, wp_y, wp_speed = self.waypoints[self.wp_index]
        dist = math.sqrt((wp_x - self.x)**2 + (wp_y - self.y)**2)

        if dist < 0.15:
            self.wp_index += 1
            if self.wp_index < len(self.waypoints):
                nwp = self.waypoints[self.wp_index]
                self.get_logger().info(
                    f'T3 | WP{self.wp_index} → ({nwp[0]:.2f},{nwp[1]:.2f})'
                )

        self.publish(wp_speed, wp_y)
        self.get_logger().info(
            f'T3 | Pos:({self.x:.2f},{self.y:.2f}) | '
            f'WP{self.wp_index}:({wp_x:.2f},{wp_y:.2f}) | '
            f'Dist:{dist:.2f}'
        )

    def publish(self, speed, lane):
        s = Float64()
        s.data = speed
        self.speed_pub.publish(s)

        l = Float64()
        l.data = lane
        self.lane_pub.publish(l)

def main(args=None):
    rclpy.init(args=args)
    node = HardwarePlanningNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()