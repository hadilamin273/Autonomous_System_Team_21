from setuptools import setup
import os
from glob import glob

package_name = 'Autonomous_Systems_Project_Team_21'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.py')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='youssefmohamed',
    maintainer_email='mosahom2003@gmail.com',
    description='Autonomous Systems Project Team 21',
    license='MIT',
    entry_points={
        'console_scripts': [
            'validation_node = Autonomous_Systems_Project_Team_21.Validation_Printing_Node_Team_21:main',
            'olr_node        = Autonomous_Systems_Project_Team_21.Autonomous_Systems_MS_2_OLR_Team_21:main',
            'teleop_node     = Autonomous_Systems_Project_Team_21.Autonomous_Systems_MS_2_Teleop_Team_21:main',
        ],
    },
)
