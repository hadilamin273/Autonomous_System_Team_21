#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import TwistStamped
from nav_msgs.msg import Odometry
import sys
import tty
import termios
import threading
import math

ARROW_UP    = '\x1b[A'
ARROW_DOWN  = '\x1b[B'
ARROW_RIGHT = '\x1b[C'
ARROW_LEFT  = '\x1b[D'

class TeleopNode(Node):

    def __init__(self):
        super().__init__('autonomous_systems_ms2_teleop_node')

        # ROS Parameters
        self.declare_parameter('initial_speed', 0.0)
        self.declare_parameter('desired_speed', 2.0)
        self.declare_parameter('initial_lane',  0.0)
        self.declare_parameter('desired_lane',  0.5)

        self.speed    = self.get_parameter('desired_speed').value
        self.steering = self.get_parameter('desired_lane').value

        self.current_speed    = 0.0
        self.current_steering = 0.0

        self.get_logger().info('=== Teleop Node Started ===')
        self.get_logger().info('UP/DOWN = speed | LEFT/RIGHT = steering | SPACE = stop | CTRL+C = exit')

        # Publisher
        self.cmd_pub = self.create_publisher(
            TwistStamped,
            '/ackermann_steering_controller/reference',
            10
        )

        # Subscriber — vehicle states
        self.odom_sub = self.create_subscription(
            Odometry,
            '/ackermann_steering_controller/odometry',
            self.odom_callback,
            10
        )

        # Keyboard thread
        self.thread = threading.Thread(target=self.keyboard_loop)
        self.thread.daemon = True
        self.thread.start()

    def get_key(self):
        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch1 = sys.stdin.read(1)
            if ch1 == '\x1b':
                ch2 = sys.stdin.read(1)
                ch3 = sys.stdin.read(1)
                return ch1 + ch2 + ch3
            return ch1
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)

    def publish_cmd(self):
        msg = TwistStamped()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = 'base_link'
        msg.twist.linear.x  = self.current_speed
        msg.twist.angular.z = self.current_steering
        self.cmd_pub.publish(msg)

    def keyboard_loop(self):
        while rclpy.ok():
            key = self.get_key()

            if key == ARROW_UP:
                self.current_speed = self.speed
                self.get_logger().info(f'Forward | Speed: {self.current_speed} m/s')
            elif key == ARROW_DOWN:
                self.current_speed = -self.speed
                self.get_logger().info(f'Backward | Speed: {self.current_speed} m/s')
            elif key == ARROW_LEFT:
                self.current_steering = self.steering
                self.get_logger().info(f'Steering Left | Angle: {self.current_steering} rad')
            elif key == ARROW_RIGHT:
                self.current_steering = -self.steering
                self.get_logger().info(f'Steering Right | Angle: {self.current_steering} rad')
            elif key == ' ':
                self.current_speed    = 0.0
                self.current_steering = 0.0
                self.get_logger().info('Stopped')
            elif key == '\x03':
                break

            self.publish_cmd()

    def odom_callback(self, msg):
        x  = msg.pose.pose.position.x
        y  = msg.pose.pose.position.y
        vx = msg.twist.twist.linear.x
        vy = msg.twist.twist.linear.y
        speed = math.sqrt(vx**2 + vy**2)
        qz  = msg.pose.pose.orientation.z
        qw  = msg.pose.pose.orientation.w
        yaw = 2.0 * math.atan2(qz, qw)

        self.get_logger().info(
            f'Position: ({x:.2f}, {y:.2f}) | '
            f'Speed: {speed:.2f} m/s | '
            f'Yaw: {math.degrees(yaw):.2f} deg'
        )

def main(args=None):
    rclpy.init(args=args)
    node = TeleopNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
