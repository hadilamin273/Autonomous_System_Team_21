#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import TwistStamped
import sys
import tty
import termios

class TeleopNode(Node):

    def __init__(self):
        super().__init__('teleop_driving_node')

        self.declare_parameter('initial_speed', 0.0)
        self.declare_parameter('desired_speed', 0.2)
        self.declare_parameter('initial_lane', 0.0)
        self.declare_parameter('desired_lane', 0.0)

        self.speed = self.get_parameter('desired_speed').value
        self.turn = self.get_parameter('desired_lane').value

        self.publisher = self.create_publisher(TwistStamped, '/cmd_vel', 10)

        self.get_logger().info("Teleop Node Started!")
        self.get_logger().info("Controls: W=forward, S=backward, A=left, D=right, Q=stop")
        self.get_logger().info(f"Speed: {self.speed} | Steering: {self.turn}")

    def get_key(self):
        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            key = sys.stdin.read(1)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
        return key

    def run(self):
        while rclpy.ok():
            key = self.get_key()
            msg = TwistStamped()
            msg.header.stamp = self.get_clock().now().to_msg()
            msg.header.frame_id = 'base_link'

            if key == 'w':
                msg.twist.linear.x = self.speed
                msg.twist.angular.z = 0.0
                self.get_logger().info("Moving Forward")
            elif key == 's':
                msg.twist.linear.x = -self.speed
                msg.twist.angular.z = 0.0
                self.get_logger().info("Moving Backward")
            elif key == 'a':
                msg.twist.linear.x = 0.0
                msg.twist.angular.z = self.turn if self.turn != 0.0 else 0.5
                self.get_logger().info("Turning Left")
            elif key == 'd':
                msg.twist.linear.x = 0.0
                msg.twist.angular.z = -(self.turn if self.turn != 0.0 else 0.5)
                self.get_logger().info("Turning Right")
            elif key == 'q' or key == '\x03':
                msg.twist.linear.x = 0.0
                msg.twist.angular.z = 0.0
                self.get_logger().info("Stopped")
                if key == '\x03':
                    break
            else:
                continue

            self.publisher.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = TeleopNode()
    node.run()
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()