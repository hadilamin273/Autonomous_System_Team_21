#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import TwistStamped
from nav_msgs.msg import Odometry
import math

class OLRNode(Node):

    def __init__(self):
        super().__init__('autonomous_systems_ms2_olr_node')

        self.cmd_pub = self.create_publisher(
            TwistStamped,
            '/ackermann_steering_controller/reference',
            10
        )

        self.odom_sub = self.create_subscription(
            Odometry,
            '/ackermann_steering_controller/odometry',
            self.odom_callback,
            10
        )

        self.timer = self.create_timer(0.1, self.publish_command)

        self.counter = 0

        self.get_logger().info("=== FINAL OLR (WORKING) ===")

    def publish_command(self):
        msg = TwistStamped()
        msg.header.stamp = self.get_clock().now().to_msg()

        phase = (self.counter // 30) % 4

        if phase == 0:
            # Forward
            msg.twist.linear.x = 2.0
            msg.twist.angular.z = 0.0
            action = "Forward"

        elif phase == 1:
            # Backward
            msg.twist.linear.x = -2.0
            msg.twist.angular.z = 0.0
            action = "Backward"

        elif phase == 2:
            # "Left" (force curve)
            msg.twist.linear.x = 2.0
            msg.twist.angular.z = 2.0   # VERY LARGE
            action = "Turn Left (approx)"

        elif phase == 3:
            # "Right"
            msg.twist.linear.x = 2.0
            msg.twist.angular.z = -2.0
            action = "Turn Right (approx)"

        self.cmd_pub.publish(msg)

        if self.counter % 30 == 0:
            self.get_logger().info(f"=== {action} ===")

        self.counter += 1

    def odom_callback(self, msg):
        x = msg.pose.pose.position.x
        y = msg.pose.pose.position.y

        qz = msg.pose.pose.orientation.z
        qw = msg.pose.pose.orientation.w
        yaw = 2.0 * math.atan2(qz, qw)

        if self.counter % 10 == 0:
            self.get_logger().info(
                f'Pos: ({x:.2f}, {y:.2f}) | Yaw: {math.degrees(yaw):.2f} deg'
            )


def main(args=None):
    rclpy.init(args=args)
    node = OLRNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
