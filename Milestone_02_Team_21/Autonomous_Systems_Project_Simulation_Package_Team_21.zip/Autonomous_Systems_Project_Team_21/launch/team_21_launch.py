from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():

    turtlebot3_gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            os.path.join(
                get_package_share_directory('turtlebot3_gazebo'),
                'launch', 'turtlebot3_world.launch.py'
            )
        ])
    )

    teleop_node = Node(
        package='Autonomous_Systems_Project_Team_21',
        executable='teleop_node',
        name='teleop_driving_node',
        parameters=[{
            'initial_speed': 0.0,
            'desired_speed': 0.2,
            'initial_lane': 0.0,
            'desired_lane': 0.5,
        }],
        output='screen'
    )

    return LaunchDescription([
        turtlebot3_gazebo,
        teleop_node,
    ])
