from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import IncludeLaunchDescription, ExecuteProcess
from launch.launch_description_sources import PythonLaunchDescriptionSource
from ament_index_python.packages import get_package_share_directory
import os

# ─────────────────────────────────────────────
# SET TO 'olr' OR 'teleop' TO SWITCH MODE
DRIVING_MODE = 'olr'
# ─────────────────────────────────────────────

def generate_launch_description():

    # ── Ackermann Car in Empty World ──
    ackermann_gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            os.path.join(
                get_package_share_directory('gz_ros2_control_demos'),
                'launch', 'ackermann_drive_example.launch.py'
            )
        ])
    )

    # ── OLR Node ──
    olr_node = Node(
        package='Autonomous_Systems_Project_Team_21',
        executable='olr_node',
        name='autonomous_systems_ms2_olr_node',
        parameters=[{
            'initial_speed': 0.0,
            'desired_speed': 2.0,
            'initial_lane':  0.0,
            'desired_lane':  0.0,
        }],
        output='screen'
    )

    # ── Teleop Node (opens in new terminal so keyboard works) ──
    teleop_node = Node(
        package='Autonomous_Systems_Project_Team_21',
        executable='teleop_node',
        name='autonomous_systems_ms2_teleop_node',
        parameters=[{
            'initial_speed': 0.0,
            'desired_speed': 2.0,
            'initial_lane':  0.0,
            'desired_lane':  0.5,
        }],
        output='screen',
        prefix='xterm -e'
    )

    # ── rqt_graph ──
    rqt_graph = ExecuteProcess(
        cmd=['ros2', 'run', 'rqt_graph', 'rqt_graph'],
        output='screen'
    )

    # ── Select driving mode ──
    driving_node = olr_node if DRIVING_MODE == 'olr' else teleop_node

    return LaunchDescription([
        ackermann_gazebo,
        driving_node,
        rqt_graph,
    ])