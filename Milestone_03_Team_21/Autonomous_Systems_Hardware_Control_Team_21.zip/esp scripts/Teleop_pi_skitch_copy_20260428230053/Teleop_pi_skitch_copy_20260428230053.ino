#include <ESP32Servo.h>

// ===================== PINS =====================
#define ENA 14
#define IN1 26
#define IN2 27

#define SERVO_PIN 13

#define ENCODER_A 32
#define ENCODER_B 33

// ===================== PWM =====================
#define PWM_FREQ 300
#define PWM_RES 8
#define PWM_CH 0

// ===================== ENCODER =====================
#define CPR 374

// ===================== CONTROL =====================
#define MAX_RPM 180.0
float Kp = 2.0;

// ===================== SERVO =====================
Servo steeringServo;

// Full steering authority (THIS WAS THE ISSUE)
#define SERVO_CENTER 90
#define SERVO_RANGE 75   // increased from 30 → strong steering

// ===================== COMMANDS =====================
float desired_speed = 0.0;
float desired_steering = 0.0;

// ===================== ENCODER =====================
volatile long encoder_ticks = 0;
long last_ticks = 0;
unsigned long last_time = 0;

float rpm = 0.0;
int pwm_output = 0;

// ===================== ISR =====================
void IRAM_ATTR encoderISR()
{
  if (digitalRead(ENCODER_B))
    encoder_ticks++;
  else
    encoder_ticks--;
}

// ===================== SETUP =====================
void setup()
{
  Serial.begin(115200);

  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);

  pinMode(ENCODER_A, INPUT_PULLUP);
  pinMode(ENCODER_B, INPUT_PULLUP);

  attachInterrupt(digitalPinToInterrupt(ENCODER_A), encoderISR, RISING);

  // Motor PWM (isolated channel)
  ledcAttachChannel(ENA, PWM_FREQ, PWM_RES, PWM_CH);

  // Servo stable timer config
  ESP32PWM::allocateTimer(0);
  ESP32PWM::allocateTimer(1);

  steeringServo.setPeriodHertz(50);
  steeringServo.attach(SERVO_PIN, 500, 2400);
  steeringServo.write(SERVO_CENTER);

  last_time = millis();

  Serial.println("FIXED TELEOP READY");
}

// ===================== LOOP =====================
void loop()
{
  readSerial();
  updateRPM();
  speedController();
  updateSteering();

  delay(40);
}

// ===================== SERIAL =====================
void readSerial()
{
  if (Serial.available())
  {
    String data = Serial.readStringUntil('\n');

    int c = data.indexOf(',');
    if (c != -1)
    {
      desired_speed = data.substring(0, c).toFloat();
      desired_steering = data.substring(c + 1).toFloat();
    }
  }
}

// ===================== RPM =====================
void updateRPM()
{
  unsigned long now = millis();
  unsigned long dt = now - last_time;

  if (dt >= 100)
  {
    long delta = encoder_ticks - last_ticks;

    rpm = ((float)delta / CPR) * (60000.0 / dt);

    last_ticks = encoder_ticks;
    last_time = now;
  }
}

// ===================== SPEED CONTROL =====================
void speedController()
{
  float target = abs(desired_speed) * MAX_RPM;
  float actual = abs(rpm);

  float error = target - actual;

  pwm_output += (int)(Kp * error);
  pwm_output = constrain(pwm_output, 0, 255);

  if (desired_speed > 0.05)
  {
    digitalWrite(IN1, HIGH);
    digitalWrite(IN2, LOW);
    ledcWriteChannel(PWM_CH, pwm_output);
  }
  else if (desired_speed < -0.05)
  {
    digitalWrite(IN1, LOW);
    digitalWrite(IN2, HIGH);
    ledcWriteChannel(PWM_CH, pwm_output);
  }
  else
  {
    digitalWrite(IN1, LOW);
    digitalWrite(IN2, LOW);
    ledcWriteChannel(PWM_CH, 0);
    pwm_output = 0;
  }
}

// ===================== STEERING (FIXED FULL RANGE) =====================
void updateSteering()
{
  // optional light smoothing ONLY (not destructive)
  desired_steering = desired_steering * 0.85;

  int angle = SERVO_CENTER - (int)(desired_steering * SERVO_RANGE);

  angle = constrain(angle, 0, 180);

  steeringServo.write(angle);
}