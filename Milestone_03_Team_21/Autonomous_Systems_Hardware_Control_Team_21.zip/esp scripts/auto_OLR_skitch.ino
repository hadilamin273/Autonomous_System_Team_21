#include <ESP32Servo.h>

// ==================================================
// PINS
// ==================================================
#define ENA        14
#define IN1        26
#define IN2        27

#define SERVO_PIN  13

#define ENCODER_A  32
#define ENCODER_B  33

// ==================================================
// PWM
// ==================================================
#define PWM_FREQ   300
#define PWM_RES    8
#define PWM_CH     0

// ==================================================
// ENCODER
// ==================================================
#define CPR        374

// ==================================================
// CONTROL
// ==================================================
#define MAX_RPM    180.0
float Kp = 2.0;

// ==================================================
// SERVO SETTINGS
// Change if needed
// ==================================================
#define SERVO_CENTER 90
#define SERVO_LEFT   45
#define SERVO_RIGHT  135

Servo steeringServo;

// ==================================================
// ENCODER VARIABLES
// ==================================================
volatile long encoder_ticks = 0;
long last_ticks = 0;
unsigned long last_time = 0;
float rpm = 0.0;

// ==================================================
// MOTOR PWM
// ==================================================
int pwm_output = 0;

// ==================================================
// MANEUVER STRUCTURE
// ==================================================
struct Maneuver
{
  const char* name;
  float desired_speed;     // -1.0 to +1.0
  int steer_angle;
  bool dir1;
  bool dir2;
  unsigned long duration;
};

// ==================================================
// MANEUVERS (LOOPS FOREVER)
// ==================================================
Maneuver maneuvers[] =
{
  { "Forward",    0.6, SERVO_CENTER, HIGH, LOW,  3000 },
  { "Backward",  -0.6, SERVO_CENTER, LOW,  HIGH, 3000 },
  { "Turn Left",  0.5, SERVO_LEFT,   HIGH, LOW,  3000 },
  { "Turn Right", 0.5, SERVO_RIGHT,  HIGH, LOW,  3000 }
};

const int total_maneuvers =
  sizeof(maneuvers) / sizeof(maneuvers[0]);

// ==================================================
// STATE MACHINE
// ==================================================
int current_maneuver = 0;
bool maneuver_started = false;
unsigned long maneuver_start_time = 0;

// ==================================================
// ENCODER ISR
// ==================================================
void IRAM_ATTR encoderISR()
{
  if (digitalRead(ENCODER_B))
    encoder_ticks++;
  else
    encoder_ticks--;
}

// ==================================================
// SETUP
// ==================================================
void setup()
{
  Serial.begin(115200);

  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);

  pinMode(ENCODER_A, INPUT_PULLUP);
  pinMode(ENCODER_B, INPUT_PULLUP);

  attachInterrupt(
    digitalPinToInterrupt(ENCODER_A),
    encoderISR,
    RISING
  );

  // Motor PWM channel
  ledcAttachChannel(ENA, PWM_FREQ, PWM_RES, PWM_CH);

  // Servo stable setup
  ESP32PWM::allocateTimer(0);
  ESP32PWM::allocateTimer(1);

  steeringServo.setPeriodHertz(50);
  steeringServo.attach(SERVO_PIN, 500, 2400);
  steeringServo.write(SERVO_CENTER);

  last_time = millis();

  Serial.println("Stable Task 2 Loop Ready");
}

// ==================================================
// LOOP
// ==================================================
void loop()
{
  updateRPM();
  runManeuverStateMachine();

  delay(40);
}

// ==================================================
// MANEUVER LOOP STATE MACHINE
// ==================================================
void runManeuverStateMachine()
{
  // Restart forever
  if (current_maneuver >= total_maneuvers)
  {
    current_maneuver = 0;
    maneuver_started = false;
  }

  Maneuver &m = maneuvers[current_maneuver];

  // Start maneuver once
  if (!maneuver_started)
  {
    Serial.println();
    Serial.print("=== ");
    Serial.print(m.name);
    Serial.println(" ===");

    encoder_ticks = 0;
    last_ticks = 0;
    pwm_output = 0;

    // Move steering first
    steeringServo.write(m.steer_angle);

    delay(500); // allow servo to move first

    maneuver_start_time = millis();
    maneuver_started = true;
  }

  // Run speed controller
  speedControl(m.desired_speed, m.dir1, m.dir2);

  printData(m.name, m.desired_speed);

  // Finish maneuver
  if (millis() - maneuver_start_time >= m.duration)
  {
    stopMotor();

    steeringServo.write(SERVO_CENTER);

    delay(800);

    current_maneuver++;
    maneuver_started = false;
  }
}

// ==================================================
// RPM UPDATE
// ==================================================
void updateRPM()
{
  unsigned long now = millis();
  unsigned long dt = now - last_time;

  if (dt >= 100)
  {
    long delta = encoder_ticks - last_ticks;

    rpm = ((float)delta / CPR) * (60000.0 / dt);

    last_ticks = encoder_ticks;
    last_time = now;
  }
}

// ==================================================
// P CONTROLLER
// ==================================================
void speedControl(float desired_speed, bool d1, bool d2)
{
  float target = abs(desired_speed) * MAX_RPM;
  float actual = abs(rpm);

  float error = target - actual;

  pwm_output += (int)(Kp * error);

  pwm_output = constrain(pwm_output, 0, 255);

  digitalWrite(IN1, d1);
  digitalWrite(IN2, d2);

  ledcWriteChannel(PWM_CH, pwm_output);
}

// ==================================================
// STOP MOTOR
// ==================================================
void stopMotor()
{
  ledcWriteChannel(PWM_CH, 0);

  digitalWrite(IN1, LOW);
  digitalWrite(IN2, LOW);

  pwm_output = 0;
}

// ==================================================
// SERIAL MONITOR OUTPUT
// ==================================================
void printData(const char* name, float desired_speed)
{
  static unsigned long lastPrint = 0;

  if (millis() - lastPrint >= 300)
  {
    float target = abs(desired_speed) * MAX_RPM;

    Serial.print("Mode: ");
    Serial.print(name);

    Serial.print(" | Target RPM: ");
    Serial.print(target);

    Serial.print(" | Actual RPM: ");
    Serial.print(abs(rpm));

    Serial.print(" | PWM: ");
    Serial.print(pwm_output);

    Serial.print(" | Ticks: ");
    Serial.println(encoder_ticks);

    lastPrint = millis();
  }
}