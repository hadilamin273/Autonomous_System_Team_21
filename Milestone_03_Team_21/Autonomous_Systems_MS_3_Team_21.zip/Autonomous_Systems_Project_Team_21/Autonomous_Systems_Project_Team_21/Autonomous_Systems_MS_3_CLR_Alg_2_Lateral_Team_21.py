#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import TwistStamped
from nav_msgs.msg import Odometry
import math

class LateralController(Node):

    def __init__(self):
        super().__init__('autonomous_systems_ms3_lateral_controller')

        # ROS Parameters
        self.declare_parameter('desired_lane',    0.0)
        self.declare_parameter('lookahead_dist',  1.0)
        self.declare_parameter('vehicle_speed',   1.0)

        self.desired_lane    = self.get_parameter('desired_lane').value
        self.lookahead_dist  = self.get_parameter('lookahead_dist').value
        self.vehicle_speed   = self.get_parameter('vehicle_speed').value

        # Vehicle state
        self.x   = 0.0
        self.y   = 0.0
        self.yaw = 0.0

        self.get_logger().info('=== Lateral Controller (Pure Pursuit) Started ===')
        self.get_logger().info(f'Desired Lane (y): {self.desired_lane} m | Lookahead: {self.lookahead_dist} m')

        # Publisher
        self.cmd_pub = self.create_publisher(
            TwistStamped,
            '/ackermann_steering_controller/reference',
            10
        )

        # Subscriber
        self.odom_sub = self.create_subscription(
            Odometry,
            '/ackermann_steering_controller/odometry',
            self.odom_callback,
            10
        )

        # Control loop at 20Hz
        self.timer = self.create_timer(0.05, self.control_loop)

    def odom_callback(self, msg):
        self.x = msg.pose.pose.position.x
        self.y = msg.pose.pose.position.y

        # Quaternion to yaw
        qz  = msg.pose.pose.orientation.z
        qw  = msg.pose.pose.orientation.w
        self.yaw = 2.0 * math.atan2(qz, qw)

    def control_loop(self):
        # ── Pure Pursuit ──
        # Target point is ahead on the desired lane (y = desired_lane)
        # lookahead point in world frame
        target_x = self.x + self.lookahead_dist * math.cos(self.yaw)
        target_y = self.desired_lane

        # Transform target to vehicle frame
        dx = target_x - self.x
        dy = target_y - self.y

        # Lateral error in vehicle frame
        lateral_error = -math.sin(self.yaw) * dx + math.cos(self.yaw) * dy

        # Pure pursuit steering angle
        # alpha = angle to target
        alpha = math.atan2(lateral_error, self.lookahead_dist)

        # Steering command
        steering = math.atan2(2.0 * math.sin(alpha), self.lookahead_dist)

        # Clamp steering
        steering = max(-0.8, min(0.8, steering))

        msg = TwistStamped()
        msg.header.stamp    = self.get_clock().now().to_msg()
        msg.header.frame_id = 'base_link'
        msg.twist.linear.x  = self.vehicle_speed
        msg.twist.angular.z = steering

        self.cmd_pub.publish(msg)

        self.get_logger().info(
            f'Pos: ({self.x:.2f}, {self.y:.2f}) | '
            f'Desired Lane: {self.desired_lane:.2f} | '
            f'Lateral Error: {lateral_error:.2f} | '
            f'Steering: {steering:.2f} | '
            f'Yaw: {math.degrees(self.yaw):.2f} deg'
        )

def main(args=None):
    rclpy.init(args=args)
    node = LateralController()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()