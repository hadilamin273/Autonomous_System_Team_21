#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import TwistStamped
from nav_msgs.msg import Odometry
import math

class SpeedController(Node):

    def __init__(self):
        super().__init__('autonomous_systems_ms3_speed_controller')

        # ROS Parameters
        self.declare_parameter('desired_speed', 1.0)
        self.declare_parameter('kp_speed', 1.0)

        self.desired_speed = self.get_parameter('desired_speed').value
        self.kp            = self.get_parameter('kp_speed').value
        self.actual_speed  = 0.0

        self.get_logger().info('=== Speed Controller Started ===')
        self.get_logger().info(f'Desired Speed: {self.desired_speed} m/s | Kp: {self.kp}')

        # Publisher
        self.cmd_pub = self.create_publisher(
            TwistStamped,
            '/ackermann_steering_controller/reference',
            10
        )

        # Subscriber
        self.odom_sub = self.create_subscription(
            Odometry,
            '/ackermann_steering_controller/odometry',
            self.odom_callback,
            10
        )

        # Control loop at 20Hz
        self.timer = self.create_timer(0.05, self.control_loop)

    def odom_callback(self, msg):
        vx = msg.twist.twist.linear.x
        vy = msg.twist.twist.linear.y
        self.actual_speed = math.sqrt(vx**2 + vy**2)

    def control_loop(self):
        # P controller
        error          = self.desired_speed - self.actual_speed
        control_effort = self.kp * error

        # Clamp output
        control_effort = max(-5.0, min(5.0, control_effort))

        msg = TwistStamped()
        msg.header.stamp    = self.get_clock().now().to_msg()
        msg.header.frame_id = 'base_link'
        msg.twist.linear.x  = control_effort

        self.cmd_pub.publish(msg)

        self.get_logger().info(
            f'Desired: {self.desired_speed:.2f} | '
            f'Actual: {self.actual_speed:.2f} | '
            f'Error: {error:.2f} | '
            f'Control: {control_effort:.2f}'
        )

def main(args=None):
    rclpy.init(args=args)
    node = SpeedController()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

