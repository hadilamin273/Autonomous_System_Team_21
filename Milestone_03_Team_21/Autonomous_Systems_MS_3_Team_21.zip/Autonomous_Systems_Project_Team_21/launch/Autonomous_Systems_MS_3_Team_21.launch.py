from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import IncludeLaunchDescription, ExecuteProcess
from launch.launch_description_sources import PythonLaunchDescriptionSource
from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():

    # ── Ackermann Car in Empty World ──
    ackermann_gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            os.path.join(
                get_package_share_directory('gz_ros2_control_demos'),
                'launch', 'ackermann_drive_example.launch.py'
            )
        ])
    )

    # ── Speed Controller Node ──
    speed_controller = Node(
        package='Autonomous_Systems_Project_Team_21',
        executable='speed_controller',
        name='autonomous_systems_ms3_speed_controller',
        parameters=[{
            'desired_speed': 3.0,   # target speed in m/s
            'kp_speed':      1.0,   # proportional gain
        }],
        output='screen'
    )

    # ── Lateral Controller Node ──
    lateral_controller = Node(
        package='Autonomous_Systems_Project_Team_21',
        executable='lateral_controller',
        name='autonomous_systems_ms3_lateral_controller',
        parameters=[{
            'desired_lane':   5.0,  # target y position in meters
            'lookahead_dist': 1.0,  # lookahead distance in meters
            'vehicle_speed':  3.0,  # speed passed to lateral node
        }],
        output='screen'
    )

    # ── rqt_graph ──
    rqt_graph = ExecuteProcess(
        cmd=['ros2', 'run', 'rqt_graph', 'rqt_graph'],
        output='screen'
    )

    return LaunchDescription([
        ackermann_gazebo,
        speed_controller,
        lateral_controller,
        rqt_graph,
    ])